package com.krpvartstudio.sshine.view.adapters

class MainDailyListAdapter {
}